<aside id="sidebar-wrapper">
  <div class="sidebar-brand">
    <a href=""><?php echo e(config('app.name')); ?></a>
  </div>
  <div class="sidebar-brand sidebar-brand-sm">
    <a href="#"><?php echo e(strtoupper(substr(config('app.name'), 0, 2))); ?></a>
  </div>
  <ul class="sidebar-menu">
    <li class="menu-header">Dashboard</li>
    <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(url('/')); ?>"><i class="fas fa-columns"></i> <span>Dashboard</span></a></li>
    <li class="<?php echo e(request()->is('table') ? 'active' : ''); ?>"><a href="<?php echo e(url('table')); ?>"><i class="fas fa-table"></i> <span>Tables</span></a></li>
    <li class="menu-header">Users</li>
    <li><a class="nav-link" href=""><i class="fas fa-users"></i> <span>Users</span></a></li>
  </ul>
</aside>
<?php /**PATH E:\@Laravel_Project\emis-extended\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>