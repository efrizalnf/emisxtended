<?php $__env->startSection('content'); ?>
  <section class="section">
    <div class="section-header">
      <h1>Package Management</h1>
    </div>
    <div class="section-body">
      <h2 class="section-title">List of Packages Question</h2>
      <p class="section-lead">This page is for managing packages including questions and answers.</p>
      <div class="card">
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-striped table-md">
              <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>Level</th>
                <th></th>
              </tr>
              </thead>
              <tbody>
              <tr>
                <td>1</td>
                <td>Lorem</td>
                <td>Lorem ipsum dolor sit amet, consectetur adipisicing.</td>
                <td>3</td>
                <td></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\@Laravel_Project\emis-extended\resources\views/app\table.blade.php ENDPATH**/ ?>