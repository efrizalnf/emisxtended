<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Login &mdash; <?php echo e(config('app.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
</head>

<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <img src="<?php echo e(asset('assets/img/stisla-fill.svg')); ?>" alt="logo" width="100" class="shadow-light rounded-circle">
            </div>
            <?php if(session()->has('info')): ?>
            <div class="alert alert-primary">
                <?php echo e(session()->get('info')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('status')): ?>
            <div class="alert alert-info">
                <?php echo e(session()->get('status')); ?>

            </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
            <div class="simple-footer">
              Copyright &copy; <?php echo e(config('app.name')); ?> <?php echo e(date('Y')); ?>

            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
  <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\@Laravel_Project\emis-extended\resources\views/layouts\auth.blade.php ENDPATH**/ ?>